Retractable Lifting Surface :: Change Log

* 2018-1111: 0.1.5.5 (Lisias) for KSP 1.4.1+; 1.5
	+ Adding KSPe Logging facilities
* 2018-1101: 0.1.5.4 (linuxgurugamer) for KSP 1.5
	+ Version bump for 1.5 rebuild
* 2018-0826: 0.1.5.3 (linuxgurugamer) for KSP 1.4.1
	+ Updated .version file to use github instead of cybutek for version checks
* 2018-0430: 0.1.5.2 (linuxgurugamer) for KSP 1.4.1
	+ Added error message if no deploy animation found
* 2018-0317: 0.1.5.1 (linuxgurugamer) for KSP 1.4.1
	+ Updated for 1.4.1
* 2017-1011: 0.1.5 (linuxgurugamer) for KSP 1.3.1
	+ No changelog provided
* 2017-0528: 0.1.4 (linuxgurugamer) for KSP 1.3
	+ Updated for 1.3
* 2017-0401: 0.1.3 (linuxgurugamer) for KSP 1.1
	+ Added easing in of control surface after animation finishes.  Ease-in is over a period of 1 second
* 2017-0113: 0.1.2 (linuxgurugamer) for KSP 1.1
	+ Added license file
* 2016-1224: 0.1.1 (linuxgurugamer) for KSP 1.1
	+ fixed bug where control surface settings were uncontrollable
* 2016-1224: 0.1.0 (linuxgurugamer) for KSP 1.1
	+ Added info functionality for the editor
	+ Added disable of control surfaces when not fully extended
* 2016-1102: 0.0.1.3 (linuxgurugamer) for KSP 1.1
	+ No changelog provided
* 2016-1014: 0.0.1.2 (linuxgurugamer) for KSP 1.1
	+ No changelog provided
* 2016-0916: 0.0.1.1 (linuxgurugamer) for KSP 1.1 PRE-RELEASE
	+ No changelog provided
* 2016-0808: 0.0.1 (linuxgurugamer) for KSP 1.1
	+ Initial release

